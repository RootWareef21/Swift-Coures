//
//  ViewController.swift
//  HelloWorld
//
//  Created by AATCe on 08/04/2023.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var greetText: UITextField!
  
    @IBAction func clearText(_ sender: Any) {
        greetText.text = ""
        print("Clear Text Pressed!")
    }
    @IBAction func greetMeAction(_ sender: Any) {
        print("Greet Button Pressed!")
        greetText.text = "Welcome to iOS!"
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }


}

